﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class Carrier
    {
        public Carrier()
        {
        }
        private Carrier(string book, string cd, string dvd)
        {
            SetBook(book);
            SetCD(cd);
            SetDVD(dvd);
        }
        public string Book { get; set; }
        public string CD { get; set; }
        public string DVD { get; set; }

        public void SetBook(string book)
        {
            if (string.IsNullOrWhiteSpace(book))
                throw new DomainException(ErrorCodes.InvalidCarierBook, "Please provide valid data.");
            if (Book == book)
                return;
            Book = book;
        }

        public void SetCD(string cd)
        {
            if (string.IsNullOrWhiteSpace(cd))
                throw new DomainException(ErrorCodes.InvalilCarrierCD, "Please provide valid data.");
            if (CD == cd)
                return;
            CD = cd;
        }

        public void SetDVD(string dvd)
        {
            if (string.IsNullOrWhiteSpace(dvd))
                throw new DomainException(ErrorCodes.InvalidCarrierDVD, "Please provide valid data.");
            if (DVD == dvd)
                return;
            DVD = dvd;
        }

        public static Carrier Create(string book, string cd, string dvd)
        {
            return new Carrier(book, cd, dvd);
        }
    }
}
