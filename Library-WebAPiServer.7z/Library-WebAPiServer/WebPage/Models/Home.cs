﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class Home
    {
        public int CustomerCount { get; set; }
        public int AuthorCount { get; set; }
        public int DirectorCount { get; set; }
        public int PerformerCount { get; set; }
        public int BookCount { get; set; }
        public int DVDCount { get; set; }
        public int CDCount { get; set; }
        public int LendBookCount { get; set; }
        public int LendDVDCount { get; set; }
        public int LendCDCount { get; set; }
    }
}
