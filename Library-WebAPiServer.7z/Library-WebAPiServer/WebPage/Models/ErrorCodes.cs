﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class ErrorCodes
    {
        public static string InvalidCarierBook => "invalid_carrier_book";
        public static string InvalilCarrierCD => "invalid_carrier_cd";
        public static string InvalidCarrierDVD => "invalid_carrier_dvd";
    }
}
