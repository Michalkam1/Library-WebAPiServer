﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class Book
    {
        public int BookId { get; set; }
        [Required, MinLength(3), MaxLength(50)]
        public string Title { get; set; }

        public virtual Author Author { get; set; }
        public int AuthorId { get; set; }

        public virtual Customer Borrower { get; set; }
        public int BorrowerId { get; set; }

        [Required]
        [Range(0, 1000)]
        public int Availability { get; set; }

        [Display(Name = "Number in Stock")]
        [Range(1, 20)]
        public int Book_Quantity { get; set; }
    }
}
