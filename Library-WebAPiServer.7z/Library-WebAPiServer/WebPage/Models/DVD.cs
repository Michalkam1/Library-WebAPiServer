﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class DVD
    {
        public int DVDId { get; set; }
        [Required, MinLength(3), MaxLength(50)]
        public string Title { get; set; }

        public virtual Director Director { get; set; }
        public int DirectorId { get; set; }

        public virtual Customer Borrower { get; set; }
        public int BorrowerId { get; set; }

        [Required]
        [Range(0, 1000)]
        public int Availability { get; set; }

        [Display(Name = "Number in Stock")]
        [Range(1, 20)]
        public int DVD_Quantity { get; set; }
    }
}
