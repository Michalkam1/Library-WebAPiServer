﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public abstract class CarrierRentalException : Exception
    {
        public string Code { get; }

        protected CarrierRentalException()
        {
        }

        protected CarrierRentalException(string code)
        {
            Code = code;
        }

        protected CarrierRentalException(string message, params object[] args) : this(string.Empty, message, args)
        {
        }

        protected CarrierRentalException(string code, string message, params object[] args) : this(null, code, message, args)
        {
        }

        protected CarrierRentalException(Exception innerException, string message, params object[] args)
            : this(innerException, string.Empty, message, args)
        {
        }

        protected CarrierRentalException(Exception innerException, string code, string message, params object[] args)
            : base(string.Format(message, args), innerException)
        {
            Code = code;
        }
    }
}
