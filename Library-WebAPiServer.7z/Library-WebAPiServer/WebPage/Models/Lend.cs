﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class Lend
    {
        public Book Book { get; set; }
        public DVD DVD { get; set; }
        public CD CD { get; set; }
        public IEnumerable<Customer> Customers { get; set; }
    }
}
