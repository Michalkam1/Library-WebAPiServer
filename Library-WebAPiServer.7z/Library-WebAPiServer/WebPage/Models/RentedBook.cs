﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class RentedBook
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        public int BookId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? ScheduledEndDate { get; set; }
        public DateTime? ActualEndDate { get; set; }

        [Required]
        public string RentalDuration { get; set; }

        [Required]
        public StatusEnum Status { get; set; }

        public enum StatusEnum
        {
            Borrowed,
            Returned
        }


        public Customer Customer { get; set; }

        public Book Book { get; set; }

        public DateTime? DateRented { get; set; }

        public DateTime RentDate { get; set; }

        public DateTime ReturnedDate { get; set; }

        public string RentedTo { get; set; }

        public string Comments { get; set; }
    }
}
