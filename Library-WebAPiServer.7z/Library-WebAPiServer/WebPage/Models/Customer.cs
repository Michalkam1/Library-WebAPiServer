﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebPage.Models
{
    public class Customer
    {
        [Required]
        public string CustomerId { get; set; }
        [Required, MinLength(3), MaxLength(50)]
        [Display(Name = "First Name")]
        public string Cust_FName { get; set; }

        [Display(Name = "Last Name")]
        public string Cust_LName { get; set; }
    }
}
